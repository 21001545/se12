package com.lifefesta.drunPlugin;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.share.Sharer;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.SharePhoto;
import com.facebook.share.model.SharePhotoContent;
import com.facebook.share.widget.ShareDialog;
import com.unity3d.player.UnityPlayer;

public class Main {
    private final String TAG = "@ Drun::  ";
    private CallbackManager _cbMgr;
    private ShareDialog _shareDialog;
    private static Main _sharedInstance;

    public static Main SharedInstance() {
        if (_sharedInstance == null) {
            _sharedInstance = new Main(UnityPlayer.currentActivity);
        }

        return _sharedInstance;
    }

    private boolean canShowDialogWithImage() {
        return ShareDialog.canShow(SharePhotoContent.class);
    }

    private boolean canShowDialogWithLink() {
        return ShareDialog.canShow(ShareLinkContent.class);
    }

    public Main(Activity activity) {
        _shareDialog = new ShareDialog(activity);
        _cbMgr = CallbackManager.Factory.create();
    }

    public void registerShareResultCallback(
            String objectName,
            String onSuccess,
            String onCancel,
            String onError
    ) {
        _shareDialog.registerCallback(_cbMgr, new FacebookCallback<Sharer.Result>() {
            @Override
            public void onSuccess(Sharer.Result result) {
                Log.d(TAG, "onSuccess sharing! postId: " + result.getPostId());
                UnityPlayer.UnitySendMessage(objectName, onSuccess, result.getPostId());
            }

            @Override
            public void onCancel() {
                Log.d(TAG, "onCancel sharing!");
                UnityPlayer.UnitySendMessage(objectName, onCancel, "");
            }

            @Override
            public void onError(@NonNull FacebookException e) {
                StringBuilder sb = new StringBuilder();
                for (StackTraceElement el : e.getStackTrace()) {
                    sb.append(el.toString());
                }
                String stackTrace = sb.toString();

                Log.d(TAG, "onError sharing! error message: " + e.getMessage() + "\n" + "stacktrace: " + stackTrace);

                UnityPlayer.UnitySendMessage(objectName, onError, e.getMessage() + "@" + stackTrace);
            }
        });
    }

    public void shareImage(String imagePath) {
        boolean canShow = canShowDialogWithImage();

        if (!canShow)
            return;

        Bitmap img = BitmapFactory.decodeFile(imagePath);
        SharePhoto photo = new SharePhoto.Builder().setBitmap(img).build();
        SharePhotoContent content = new SharePhotoContent.Builder().addPhoto(photo).build();

        _shareDialog.show(content);
    }

    public void shareUrl(String url) {
        boolean canShow = canShowDialogWithLink();

        if (!canShow)
            return;

        ShareLinkContent content = new ShareLinkContent.Builder().setContentUrl(Uri.parse(url)).build();
        _shareDialog.show(content);
    }

    public void sendMessage_unity(String objectName, String methodName, String param) {
        UnityPlayer.UnitySendMessage(objectName, methodName, param);
    }
}
